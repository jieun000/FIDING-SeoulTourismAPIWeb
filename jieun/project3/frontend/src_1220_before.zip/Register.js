import React from 'react'

const Register = () => {
  return (
    <div>회원가입</div>
  )
}

export default Register