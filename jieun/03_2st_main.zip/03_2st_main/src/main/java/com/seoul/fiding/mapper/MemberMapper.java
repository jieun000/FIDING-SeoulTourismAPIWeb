package com.seoul.fiding.mapper;

import com.seoul.fiding.vo.MemberVO;

public interface MemberMapper {
	public void register(MemberVO vo);
}
