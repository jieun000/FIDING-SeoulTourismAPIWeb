import React from 'react'

const Menu1 = () => {
  return (
    <div>Menu1</div>
  )
}

export default Menu1