package com.five.coding.controller;

import java.io.File;
import java.io.IOException;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api")
public class FileUploadController {

    @PostMapping("/upload")
    public String handleFileUpload(@RequestParam("file") MultipartFile file, @RequestParam("id") String id) {
    	System.out.println("file Controller 진입"+ file+", id:" +id);
        if (file.isEmpty()) {
            return "File is empty";
        }

        // You can access file information like name and content type
        String fileName = file.getOriginalFilename();
        //String contentType = file.getContentType();
        
        try {
            // Specify the base directory where you want to save the file
            String baseDirectory = "c://upload/";

            // Specify the relative directory based on some logic (e.g., user-specific directory)
            String relativeDirectory = id+"/";

            // Combine the base directory and relative directory to create the complete directory path
            String completeDirectoryPath = baseDirectory + relativeDirectory;

            // Create directories if they don't exist
            File directory = new File(completeDirectoryPath);
            if (!directory.exists()) {
                directory.mkdirs(); // This will create the directory and its parent directories if they don't exist
            }

            // Combine the directory and file name to create the complete file path
            String filePath = completeDirectoryPath + fileName;

            // Save the file
            file.transferTo(new File(filePath));

            // Process the file as needed (e.g., save file information to a database)

            // Return success message or redirect to another page
            return "upload-success";
        } catch (IOException e) {
            // Handle file processing exception
            e.printStackTrace();
            return "upload-failure";
        }

    }
}
