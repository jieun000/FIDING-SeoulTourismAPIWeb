package com.five.coding.service;

import com.five.coding.vo.MemberVO;

public interface MemberService {
	public void register(MemberVO vo); //회원가입
	public MemberVO isSignup(MemberVO  vo); //멤버 정보 불러오기
	public void updateBoard(MemberVO vo); //회원 수정 업데이트

}
