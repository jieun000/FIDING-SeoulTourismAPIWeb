package com.five.coding.mapper;

import com.five.coding.vo.MemberVO;



public interface MemberMapper {
	
	public void register(MemberVO vo);
	public MemberVO isSignup(String id);

}
