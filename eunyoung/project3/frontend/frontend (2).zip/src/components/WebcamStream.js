import React, { useEffect, useRef, useState } from 'react';
import './loading.css';  // 위에서 작성한 CSS 파일 import

const WebcamStream = () => {
  const [showImage, setShowImage] = useState(false);
  const [loading, setLoading] = useState(false);

  const recognition = async () => {
    const response = await fetch('http://localhost:5000/api/video_feed2');
    console.log("리스폰 확인", response);
    try {
      setLoading(true);
      const result = await response.blob();
      console.log("클릭 함수실행", result);
      // console.log(result.user_id);
      setShowImage(true);
    } catch (error) {
      console.error('웹캠불러오기 에러', error);
    } finally {
      setLoading(false);
    }
  };
  
  // useEffect(() => {
  //   console.log("로딩 확인", loading);
  // }, [loading]);
  
  const handleButtonClick = async () => {
    await recognition();
  };


  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      height: '50vh',
      marginBottom: '280px',
    }}>
      {loading && !showImage && <div className="spinner" style={{marginBottom:'20px'}}/>} {/* 로딩 스피너 표시 */}
      
      {showImage && (<div style={{marginTop: showImage ? '270px' : '0'}}>
          <img
            src="http://localhost:5000/api/video_feed2"
            alt="Video"
          />
        </div>
      )}
      <button onClick={handleButtonClick} style={{
        fontSize: '40px',
        padding: '5px 5px',
        border: '4px solid pink',
        background: 'white',
        marginBottom: '20px',
      }}>📸</button>

      <p>얼굴 인증을 원하시면 카메라를 클릭 해주세요!</p>
    </div>
  );
};

export default WebcamStream;
