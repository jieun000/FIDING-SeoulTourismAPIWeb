import React from 'react'

const Cap = () => {
  return (
    <div>
    <img
     src="http://localhost:5000/video_feed"
     alt="Video"
    />
   </div>
  )
}

export default Cap