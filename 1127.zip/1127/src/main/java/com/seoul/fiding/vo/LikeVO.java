package com.seoul.fiding.vo;

import lombok.Data;

@Data
public class LikeVO {

	private int LL_NO ;
	private int BD_NO ;
	private String WRITER_ID;
	private String USER_ID;
	
}