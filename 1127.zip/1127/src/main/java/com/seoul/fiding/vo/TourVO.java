package com.seoul.fiding.vo;

import lombok.Data;

@Data
public class TourVO {

	private int TL_NO ;
	private String cat;
	private String address;
	private int search_cnt ;
	
}