package com.seoul.fiding.vo;

import lombok.Data;

@Data
public class FavorVO {

	private int FL_NO ;
	private int BD_NO ;
	private String WRITER_ID;
	private String USER_ID;
	
}